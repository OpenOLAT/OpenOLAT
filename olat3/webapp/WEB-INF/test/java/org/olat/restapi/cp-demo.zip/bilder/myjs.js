function testIt(){
alert("Java script include works");
} 
